const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
app.use(express.static("public"));
//parse json requests
app.use(express.json());
const mongoose = require('mongoose');

//set pug as the view engine and set views as the directory where pug files will be located
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1/artGallery');

const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const store = new MongoDBStore({
	uri: 'mongodb://127.0.0.1:27017/artGallery',
	collection: 'sessiondata'
});
app.use(session({ 
	secret: 'some secret key here', 
	resave: true,
	saveUninitialized: true,
	store: store
}));




//models being called here
const Artwork = require('./models/artwork'); 
const User = require('./models/user');




app.use((req, res, next) => {
    console.log(`${req.method} request to ${req.path}`);
    next();
});



// login when server starts
app.get('/', (req, res) => {
    res.render('login'); 
});

app.post('/', async (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    try {
        let user = await User.findOne({ username }).select('-password').exec();

        if (!user) {
            user = new User({
                username,
                password,
                accountType: 'patron'
            });

            await user.save();
        }

        req.session.user = {
            _id: user._id, 
            username: user.username,
            accountType: user.accountType
        };

        res.redirect('/userinfo');
    } catch (error) {
        console.error('Error during user authentication:', error);
        res.status(500).send('Server error');
    }
});



// Userinfo route, like a home page basically
app.get('/userinfo', async (req, res) => {
    try {
        const artworkCount = await Artwork.countDocuments({ Artist: req.session.user.username });
        const user = await User.findById(req.session.user._id).populate('liked reviewed following followers');
        res.render('userinfo', { 
          username: req.session.user.username, 
          accountType: req.session.user.accountType,
          artworkCount,
          likedArtworks: user.liked,
          reviewedArtworks: user.reviewed,
          followedArtists: user.following,
          followers: user.followers,
        })
    } catch (error) {
        console.error('Error getting artwork count:', error);
        res.status(500).send('Server Error');
    }
});



// Logout route
app.post('/logout', (req, res) => {
    // Destroy the session
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            res.status(500).send('Server Error');
        } else {
            // Redirect to the login page after logout
            res.redirect('/');
        }
    });
});



// to change account type from patron to artist or vice versa
app.get('/changeacctype', async (req, res) => {
    try {
        // get the user from the database based on the session information
        const user = await User.findOne({ username: req.session.user.username });

        // get the artwork count associated with the artist's username
        const artworkCount = await Artwork.countDocuments({ Artist: user.username });

        // open the pug page associated with this
        res.render('changeacctype', { accountType: req.session.user.accountType, artworkCount });
    } catch (error) {
        console.error('Error getting user data:', error);
        res.status(500).send('Server Error');
    }
});

app.post('/updateAccount', async (req, res) => {
    const newAccountType = req.body.accountType;

    if (req.session.user) {
        try {
            // Update the account type in the session
            req.session.user.accountType = newAccountType;

            // Save the updated user information in the database
            await User.updateOne({ username: req.session.user.username }, { accountType: newAccountType });

            res.status(200).send('Account updated successfully!');
        } catch (error) {
            console.error('Error updating account:', error);
            res.status(500).send('Server Error');
        }
    } else {
        res.status(401).send('Unauthorized');
    }
});


//adding artwork page
app.get('/addartwork', (req, res) => {
    res.render('addartwork', {accountType: req.session.user.accountType});
});



//adding artwork to server
app.post('/addArtwork', async (req, res) => {
    // get artwork details from the request body
    const { Title, Year, Category, Medium, Description, Poster } = req.body;

    if (req.session.user) {
        try {
            // Check if an artwork with the same title already exists
            const existingArtwork = await Artwork.findOne({ Title });

            if (existingArtwork) {
                // If the artwork with the same title exists, send an error response
                return res.status(400).send('Artwork with the same title already exists.');
            }

            // Create and save the artwork
            const artwork = new Artwork({
                Title,
                Artist: req.session.user.username,
                Year,
                Category,
                Medium,
                Description,
                Poster
            });

            await artwork.save();


            // Update the account type to 'artist' after saving the artwork
            req.session.user.accountType = 'artist';

            // get the user with the 'followers' array populated
            const userWithFollowers = await User.findById(req.session.user._id).populate('followers');

            console.log('Followers array:', userWithFollowers.followers);

            // Notify followers about the new artwork
            const followers = userWithFollowers.followers;

            followers.forEach(async (follower) => {
                // Update the user's notifications array
                follower.notifications.push({
                    content: `${req.session.user.username} has added a new artwork: ${Title}`,
                });
                await follower.save();
            });

            console.log('Session user after adding artwork:', req.session.user);

            // Send a success response
            res.status(200).send('Artwork added successfully! Account upgraded to artist.');
        } catch (error) {
            console.error('Error adding artwork:', error);
            res.status(500).send('Server Error');
        }
    } else {
        res.status(401).send('Unauthorized');
    }
});




// route for checking if the user has artwork
app.get('/checkArtwork', async (req, res) => {
    try {
        // Check if the user already has artwork
        const artworkCount = await Artwork.countDocuments({ Artist: req.session.user.username });

        if (artworkCount > 0) {
            // If the user has artwork, send a success response 
            res.status(200).send('User has artwork.');
        } else {
            // If the user doesn't have artwork, send a failure response 
            res.status(403).send('User does not have artwork.');
        }
    } catch (error) {
        console.error('Error checking artwork:', error);
        res.status(500).send('Server Error');
    }
});




// route for the search page
app.get('/search', (req, res) => {
    res.render('search', {accountType: req.session.user.accountType});
});
  
// route for search requests
app.post('/search', async (req, res) => {
    const { title, artist, category } = req.body;
  
    try {
      // case-insensitive query for searching artworks
      const query = {
        Title: { $regex: new RegExp(title, 'i') },
        Artist: { $regex: new RegExp(artist, 'i') },
        Category: { $regex: new RegExp(category, 'i') }
      };
  
      // search the database
      const artworks = await Artwork.find(query);
  
      // Render the search results page
      res.render('searchresults', { artworks, accountType: req.session.user.accountType,});
    } catch (error) {
      console.error('Error during search:', error);
      res.status(500).send(`Server Error: ${error.message}`);
    }
});





// route for search results
app.get('/searchresults', async (req, res) => {
    try {
        // Get the search criteria from the query string
        const { title, artist, category } = req.query;

        // Build the filter based on given search fields
        const filter = {};
        if (title) filter.Title = new RegExp(title, 'i');
        if (artist) filter.Artist = new RegExp(artist, 'i');
        if (category) filter.Category = new RegExp(category, 'i');

        const searchResults = await Artwork.find(filter);

        // Render the searchresults.pug template with the search results
        res.render('searchresults', { results: searchResults, accountType: req.session.user.accountType });
    } catch (error) {
        console.error('Error getting search results:', error);
        res.status(500).send('Server Error');
    }
});




// getting specific artwork
app.get('/artwork/:id', async (req, res) => {
    try {
        // getthe artwork details based on the provided ID and populate the 'user' field for reviews
        const artwork = await Artwork.findById(req.params.id).populate('reviews.user');
        console.log('Artwork from db:', artwork);

        if (!artwork) {
            // If the artwork with the provided ID doesn't exist
            res.status(404).send('Artwork not found.');
            return;
        }

        const user = await User.findOne({ username: req.session.user.username });

        // Render the artworkinfo.pug template with the artwork and user details
        res.render('artworkinfo', { artwork, user, accountType: req.session.user.accountType, });
    } catch (error) {
        console.error('Error getting artwork details:', error);
        res.status(500).send('Server Error');
    }
});



// for liking an artwork
app.post('/likeArtwork/:id', async (req, res) => {
    try {
        const artworkId = req.params.id;
        const userId = req.session.user._id;

        // get the artwork to check the artist
        const artwork = await Artwork.findById(artworkId);

        if (!artwork) {
            return res.status(404).send('Artwork not found.');
        }

        // Check if the user (artist) is trying to like their own artwork
        if (artwork.Artist === req.session.user.username) {
            return res.status(400).send('You cannot like your own artwork.');
        }

        // get the user including the liked field
        const user = await User.findById(userId).select('liked');
        console.log('User from db:', user);

        if (!user) {
            // If the user is not found
            console.error('User not found.');
            return res.status(404).send('User not found.');
        }


        console.log('user from db:', user);

        // Check if the user has already liked the artwork
        const userLiked = user.liked.includes(artworkId);

        if (userLiked) {
            // User has already liked the artwork, unlike it
            await User.findByIdAndUpdate(userId, { $pull: { liked: artworkId } });
            await Artwork.findByIdAndUpdate(artworkId, { $inc: { likes: -1 } });

            // response with a message indicating that the user cannot like their own artwork
            res.status(400).send('You cannot like your own artwork.');
        } else {
            // User hasn't liked the artwork, like it
            await User.findByIdAndUpdate(userId, { $push: { liked: artworkId } });
            await Artwork.findByIdAndUpdate(artworkId, { $inc: { likes: 1 } });

            res.status(200).send('Artwork liked successfully!');
        }
    } catch (error) {
        console.error('Error liking/unliking artwork:', error);
        res.status(500).send('Server Error');
    }
});

// for unliking artwork
app.post('/unlikeArtwork/:id', async (req, res) => {
    try {
        const artworkId = req.params.id;
        const userId = req.session.user._id;

        // Check if the user has already liked the artwork
        const user = await User.findById(userId);
        const userLiked = user.liked.includes(artworkId);

        if (userLiked) {
            // User has already liked the artwork, unlike it
            await User.findByIdAndUpdate(userId, { $pull: { liked: artworkId } });
            await Artwork.findByIdAndUpdate(artworkId, { $inc: { likes: -1 } });
        } else {
            // User hasn't liked the artwork so no need to unlike
            res.status(400).send('User has not liked the artwork.');
            return;
        }

        res.status(200).send('Artwork unliked successfully!');
    } catch (error) {
        console.error('Error unliking artwork:', error);
        res.status(500).send('Server Error');
    }
});



// for adding a review
app.post('/addReview/:id', async (req, res) => {
    const artworkId = req.params.id;
    const userId = req.session.user._id;
    const reviewText = req.body.text;

    try {
        // Find the artwork
        const artwork = await Artwork.findById(artworkId);

        // Check if the user is trying to add a review to their own artwork
        if (artwork.Artist === req.session.user.username) {
            return res.status(400).send('You cannot review your own artwork.');
        }

        // Add the review to the artwork
        artwork.reviews.push({ user: userId, text: reviewText });
        await artwork.save();

        // Add the artwork to the user's reviewed list
        await User.findByIdAndUpdate(userId, { $addToSet: { reviewed: artworkId } });

        res.redirect(`/artwork/${artworkId}`);
    } catch (error) {
        console.error('Error adding review:', error);
        res.status(500).send('Server Error');
    }
});


// for removing a review
app.post('/removeReview/:id', async (req, res) => {
    const artworkId = req.params.id;
    const userId = req.session.user._id;

    try {
        // Find the artwork
        const artwork = await Artwork.findById(artworkId);

        // Remove the review from the artwork
        artwork.reviews = artwork.reviews.filter(review => !review.user.equals(userId));
        await artwork.save();

        // Remove the artwork from the user's reviewed list
        await User.findByIdAndUpdate(userId, { $pull: { reviewed: artworkId } });

        res.redirect(`/artwork/${artworkId}`);
    } catch (error) {
        console.error('Error removing review:', error);
        res.status(500).send('Server Error');
    }
});




// getting the info of the specified artist through clicking their name as a link
app.get('/artistinfo/:username', async (req, res) => {
    const userId = req.session.user._id;
    const currentUser = await User.findById(userId);
    try {
        const artistUsername = req.params.username;

        // get the artist's artworks
        const artworks = await Artwork.find({ Artist: artistUsername });

        // get the artist's workshops 
        const artist = await User.findOne({ username: artistUsername }).populate('workshops');

        // to make sure artist is always defined
        const artistInfo = artist || {};

        // Render the artistinfo.pug template with the artworks and workshops
        res.render('artistinfo', { currentUser, artworks, user: artistInfo, accountType: req.session.user.accountType });
    } catch (error) {
        console.error('Error getting artist information:', error);
        res.status(500).send('Server Error');
    }
});


// route for rendering add workshop page
app.get('/addworkshop', (req, res) => {
    res.render('addworkshop', {accountType: req.session.user.accountType});
});

// for adding a workshop
app.post('/addworkshop', async (req, res) => {
    const userId = req.session.user._id;
    const user = await User.findById(userId);

    try {
        // Check if the user is logged in and has the expected properties
        if (user.accountType === 'artist') {
            const newWorkshop = {
                title: req.body.title,
            };

            // Add the workshop object to the user's workshops array
            user.workshops.push(newWorkshop);
            await user.save();

            // Notify followers about the new workshop
            const followers = await User.find({ _id: { $in: req.session.user.followers } });

            followers.forEach(async (follower) => {
                follower.notifications.push(`${req.session.user.username} has added a new workshop: ${newWorkshop.title}`);
                await follower.save();
            });

            res.status(200).send('Workshop successfully added');
        } else {
            res.status(403).send('Unauthorized');
        }
    } catch (error) {
        console.error('Error adding workshop:', error);
        res.status(500).send('Server Error');
    }
});



// to enroll in a workshop by clicking the workshop name link
app.post('/enrollWorkshop/:id', async (req, res) => {
    const workshopId = req.params.id;
    const userId = req.session.user._id;

    try {
        // Check if the user is logged in
        if (!userId) {
            return res.status(401).send('Unauthorized');
        }

        // Find the user
        const user = await User.findById(userId);

        // Check if the user exists
        if (!user) {
            return res.status(404).send('User not found.');
        }
        console.log('User Workshops:', user.workshops);

        // Check if the user is already enrolled in the workshop
        const isEnrolled = user.enrolledws.some(ws => ws._id.equals(workshopId));
        if (isEnrolled) {
            return res.status(400).send('User is already enrolled in this workshop.');
        }

        // Find the workshop in the user's workshops
        const workshop = user.workshops.find(ws => ws._id.equals(workshopId));

        if (!workshop) {
            return res.status(404).send('Workshop not found.');
        }

        // Enroll the user
        user.enrolledws.push(workshop);
        await user.save();

        res.status(200).send('Enrolled in the workshop successfully.');
    } catch (error) {
        console.error('Error enrolling in workshop:', error);
        res.status(500).send('Server Error');
    }
});





// route to follow an artist
app.post('/followArtist', async (req, res) => {
    try {
        const { artistUsername } = req.body;
        const userId = req.session.user._id;
        const currentUser = await User.findById(userId);

        // Find the artist user in db
        const artistUser = await User.findOne({ username: artistUsername });

        // Check if the artist user exists and is not already followed
        if (artistUser && !currentUser.following.includes(artistUser._id)) {
            // Update the user's following array
            currentUser.following.push(artistUser._id);
            await currentUser.save();

            // Update the artist's followers array
            artistUser.followers.push(currentUser._id);
            await artistUser.save();

            res.status(200).send('Successfully followed artist.');
        } else {
            res.status(400).send('Error following artist.');
        }
    } catch (error) {
        console.error('Error following artist:', error);
        res.status(500).send('Server Error');
    }
});


// route to unfollow an artist
app.post('/unfollowArtist', async (req, res) => {
    try {
        const { artistUsername } = req.body;
        const userId = req.session.user._id;
        const currentUser = await User.findById(userId);

        // Find the artist user in the db
        const artistUser = await User.findOne({ username: artistUsername });

        // Check if the artist user exists and is followed
        if (artistUser && currentUser.following.includes(artistUser._id)) {
            // Remove the artist from the user's following array
            currentUser.following = currentUser.following.filter(id => id.toString() !== artistUser._id.toString());
            await currentUser.save();

            // Remove the user from the artist's followers array
            artistUser.followers = artistUser.followers.filter(id => id.toString() !== currentUser._id.toString());
            await artistUser.save();

            res.status(200).send('Successfully unfollowed artist.');
        } else {
            res.status(400).send('Error unfollowing artist.');
        }
    } catch (error) {
        console.error('Error unfollowing artist:', error);
        res.status(500).send('Server Error');
    }
});



app.get('/notifications', async (req, res) => {
    try {
      const userId = req.session.user._id;
      const currentUser = await User.findById(userId);
  
      // get artist information for each notification using findById
      const notificationsWithArtists = [];
      for (const notification of currentUser.notifications) {
        try {
          const artist = await User.findById(notification.artist);
          notificationsWithArtists.push({
            artist: artist ? artist.username : 'Unknown Artist',
            type: notification.type,
          });
        } catch (error) {
          console.error('Error getting artist information:', error);
          notificationsWithArtists.push({
            artist: 'Unknown Artist',
            type: notification.type,
          });
        }
      }
  
      console.log('Notifications sent to the client:', notificationsWithArtists);
  
      // Render the notifications.pug template with the user's notifications and artist information
      res.render('notifications', { user: currentUser, notifications: notificationsWithArtists });
    } catch (error) {
      console.error('Error getting notifications:', error);
      res.status(500).send('Server Error');
    }
});

// Run the function and handle any errors
async function run() {
    try {
        // Initialize the database before starting the server
        //await initializeDatabase();
    } catch (error) {
        console.log('Error during database initialization:', error);
        process.exit(1); // Exit the process if there's an error
    } finally {
        app.listen(3000);
        console.log('Server running on Port 3000');
        console.log("Server listening at http://localhost:3000");
    }
}
run().catch(console.dir);