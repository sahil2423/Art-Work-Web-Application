const path = require('path');
const fs = require('fs');
//app.use(express.static("public"));
const mongoose = require('mongoose');
//parse json requests
//app.use(express.json());

// Create a separate file for the Artwork schema/model and User schema/model
const Artwork = require('./models/artwork');
const User = require('./models/user');


// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1/artGallery');

// Initialize the MongoDB database with data from gallery.json
const initializeDatabase = async () => {
    try {
        // Read the content of gallery.json
        const galleryData = fs.readFileSync('gallery.json', 'utf-8');
      
        // Parse the JSON data
        const artworkArray = JSON.parse(galleryData);
  
        // Insert data into the Artwork collection
        await Artwork.insertMany(artworkArray);
  
        console.log('Database initialized successfully!');


        // Get unique artist names from artworks
        const artists = await Artwork.distinct('Artist').exec();

        // Create user accounts for each artist
        for (const artist of artists) {
            let user = await User.findOne({ username: artist }).select('-password').exec();

            if (!user) {
                // If the user doesn't exist, create a new user account for the artist
                user = new User({
                    username: artist,
                    password: 'artistDefaultPassword', //default password
                    accountType: 'artist'
                });

                await user.save();
                console.log(`User account created for artist: ${artist}`);
            }
        }

        console.log('User population completed!');
    } catch (error) {
        console.log('Error initializing database:', error);
    }
};

initializeDatabase();