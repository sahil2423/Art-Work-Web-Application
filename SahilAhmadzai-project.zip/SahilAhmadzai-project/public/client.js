function login(){
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    // make sure that the form fields are not empty
    if (!username || !password) {
        console.log("Username or password field is missing");
        return;
    }

    console.log("username: ", username);
    console.log("password: ", password);

    let req = new XMLHttpRequest();

    req.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log("Server response:", this.responseText);
            // Redirect to userinfo.pug using window.location.href
            window.location.href = '/userinfo';
            
        }
    };


    req.open('POST', '/', true);
    req.setRequestHeader('Content-Type', 'application/json');

    req.send(JSON.stringify({username: username, password: password}));
}





// function for upgrading the account
function upgradeAccount() {
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                // User has artwork, proceed with the upgrade
                sendAccountUpdateRequest('artist');
            } else {
                // User doesn't have artwork, show confirmation msg
                const confirmResult = window.confirm("You need to add a piece of art first. Do you want to add artwork now?");

                // If user clicks OK, redirect to addartwork page
                if (confirmResult) {
                    window.location.href = '/addartwork';
                }
            }
        }
    };

    req.open('GET', '/checkArtwork', true);
    req.send();
}

// New function to show the add artwork form
function showAddArtworkForm() {
    // Check if the form exists
    const addArtworkForm = document.getElementById('addArtworkForm');
    if (addArtworkForm) {
        addArtworkForm.style.display = 'block';
    } else {
        console.error('Add artwork form not found.');
    }
}

// New function for downgrading the account
function downgradeAccount() {
    sendAccountUpdateRequest('patron');
}

// Helper function to send an account update request
function sendAccountUpdateRequest(accountType) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            console.log("Server response:", this.responseText);
            alert("Account updated successfully!");
            // Redirect to userinfo.pug using window.location.href
            window.location.href = '/userinfo';
        }
    };

    req.open('POST', '/updateAccount', true);
    req.setRequestHeader('Content-Type', 'application/json');
    req.send(JSON.stringify({ accountType: accountType }));
}


// function to add artwork
function addArtwork() {
    const Title = document.getElementById('title').value;
    const Year = document.getElementById('year').value;
    const Category = document.getElementById('category').value;
    const Medium = document.getElementById('medium').value;
    const Description = document.getElementById('description').value;
    const Poster = document.getElementById('poster').value;

    // Ensure all fields are not empty
    if (!Title || !Year || !Category || !Medium || !Description || !Poster) {
        alert('Please fill in all fields.');
        return;
    }

    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                console.log('Server response:', this.responseText);

                // calling upon helper function
                sendAccountUpdateRequest('artist');
            } else {
                console.error('Server error. Status:', this.status, 'Response:', this.responseText);
                alert('Error adding artwork. Please try again.');
            }
        }
    };

    req.open('POST', '/addArtwork', true);
    req.setRequestHeader('Content-Type', 'application/json');

    // Send the artwork details as JSON in the request body
    req.send(JSON.stringify({ Title, Year, Category, Medium, Description, Poster }));
}




// New function for searching artworks
function searchArtworks() {
    const title = document.getElementById('title').value;
    const artist = document.getElementById('artist').value;
    const category = document.getElementById('category').value;

    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                console.log('Server response:', this.responseText);

                // Update the current page with the search results
                document.body.innerHTML = this.responseText;
            } else {
                console.error('Server error. Status:', this.status, 'Response:', this.responseText);
                alert('Error searching for artworks. Please try again.');
            }
        }
    };

    req.open('POST', '/search', true);
    req.setRequestHeader('Content-Type', 'application/json');

    // Send the search details as JSON in the request body
    req.send(JSON.stringify({ title, artist, category }));
}





// Function to toggle liking an artwork
function toggleLike(artworkId) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                console.log("Server response:", this.responseText);
                window.location.reload();
            } else {
                console.error("Error toggling like:", this.status, this.responseText);

                // Show an alert if the user is trying to like their own artwork
                if (this.responseText.includes("cannot like your own artwork")) {
                    alert("You cannot like your own artwork.");
                } else {
                    alert("Error toggling like. Please try again.");
                }
            }
        }
    };

    req.open('POST', `/likeArtwork/${artworkId}`, true);
    req.send();
}

// Function to toggle unliking an artwork
function toggleUnlike(artworkId) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200) {
                console.log("Server response:", this.responseText);
                window.location.reload();
            } else {
                console.error("Error toggling unlike:", this.status, this.responseText);
                alert("Error toggling unlike. Please try again.");
            }
        }
    };

    req.open('POST', `/unlikeArtwork/${artworkId}`, true);
    req.send();
}



// helper function for adding review
function toggleAddReviewForm(artworkId) {
    const addReviewForm = document.getElementById(`addReviewForm_${artworkId}`);
    addReviewForm.style.display = addReviewForm.style.display === 'none' ? 'block' : 'none';
}

// function for adding a review to an artwork
function addReview(artworkId) {
    const reviewText = document.getElementById(`reviewText_${artworkId}`).value;

    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (req.readyState === 4) {
            if (req.status === 200) {
                location.reload();
            } else {
                console.error('Error adding review:', req.statusText);

                // Show an alert if the user is trying to add a review to their own artwork
                if (req.responseText.includes("cannot review your own artwork")) {
                    alert("You cannot add a review to your own artwork.");
                } else {
                    alert('Error adding review. Please try again.');
                }
            }
        }
    };

    req.open('POST', `/addReview/${artworkId}`, true);
    req.setRequestHeader('Content-Type', 'application/json');

    const data = JSON.stringify({ text: reviewText });
    req.send(data);
}

// function for removing a review from an artwork
function removeReview(artworkId) {
    let req = new XMLHttpRequest();
  
    req.onreadystatechange = function () {
      if (req.readyState === 4) {
        if (req.status === 200) {
          location.reload();
        } else {
          console.error('Error removing review:', req.statusText);
        }
      }
    };
  
    req.open('POST', `/removeReview/${artworkId}`, true);
    req.send();
}


// function for adding a workshop
function addWorkshop() {
    // Prevent the default form submission behavior
    event.preventDefault();

    let title = document.getElementById("title").value;

    // make sure that the form fields are not empty
    if (!title) {
        console.log("Title field is missing");
        return false;
    }

    let req = new XMLHttpRequest();

    req.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                console.log("Server response:", this.responseText);
                // Show alert when workshop added successfully
                alert("Workshop successfully added!");
                // Redirect to userinfo.pug using window.location.href
                window.location.href = '/userinfo';
            } else if (this.status == 403) {
                console.error("Unauthorized. Redirecting to login page");
                window.location.href = '/';
            } else {
                console.error("Error adding workshop:", this.status, this.responseText);
                alert("Error adding workshop. Please try again.");
            }
        }
    };

    req.open('POST', '/addworkshop', true);
    req.setRequestHeader('Content-Type', 'application/json');

    req.send(JSON.stringify({ title: title }));
}


//function for enrolling in a workshop after clicking link of workshop name
function enrollWorkshop(workshopId) {
    let confirmEnrollment = confirm('Do you want to enroll in this workshop?');
    if (confirmEnrollment) {
        let req = new XMLHttpRequest();

        req.onreadystatechange = function () {
            if (req.readyState == 4) {
                if (req.status == 200) {
                    alert('Successfully enrolled in this workshop.');
                    window.location.reload();
                } else {
                    console.error('Error enrolling in workshop:', req.status, req.responseText);
                    alert('Error enrolling in workshop. Please try again.');
                }
            }
        };

        req.open('POST', `/enrollWorkshop/${(workshopId)}`, true);
        req.send();
    }
}



// Function to follow an artist
function followArtist(artistUsername) {
    console.log("artistUsername in client: ", artistUsername);
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (req.readyState == 4) {
            if (req.status == 200) {
                alert('Successfully followed artist.');
                document.getElementById('followBtn').disabled = true;
                document.getElementById('unfollowBtn').disabled = false;
            } else {
                console.error('Error following artist:', req.status, req.responseText);
                alert('Error following artist. Please try again.');
            }
        }
    };

    req.open('POST', '/followArtist', true);
    req.setRequestHeader('Content-Type', 'application/json'); // Set the content type to JSON
    req.send(JSON.stringify({ artistUsername: artistUsername })); // Send artistUsername as JSON
}


//function to unfollow an artist
function unfollowArtist(artistUsername) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = function () {
        if (req.readyState == 4) {
            if (req.status == 200) {
                alert('Successfully unfollowed artist.');
                document.getElementById('followBtn').disabled = false;
                document.getElementById('unfollowBtn').disabled = true;
            } else {
                console.error('Error unfollowing artist:', req.status, req.responseText);
                alert('Error unfollowing artist. Please try again.');
            }
        }
    };

    req.open('POST', '/unfollowArtist', true);
    req.setRequestHeader('Content-Type', 'application/json');
    req.send(JSON.stringify({ artistUsername: artistUsername }));
}