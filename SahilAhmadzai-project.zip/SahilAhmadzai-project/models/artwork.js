const mongoose = require('mongoose');

const artworkSchema = new mongoose.Schema({
  Title: String,
  Artist: String,
  Year: String,
  Category: String,
  Medium: String,
  Description: String,
  Poster: String,
  likes: { type: Number, default: 0 }, // new field for artwork likes
  reviews: [
    {
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        text: String,
    }
  ] // new field for artwork reviews
});

// Create a Mongoose model for the 'Artwork' collection using the schema
const Artwork = mongoose.model('Artwork', artworkSchema);

// Export the model to be used in other parts of app
module.exports = Artwork;