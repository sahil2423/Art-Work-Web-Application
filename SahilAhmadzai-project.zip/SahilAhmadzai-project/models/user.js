const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  password: { type: String, required: true, select: false }, // exclude password from query results
  accountType: { type: String, enum: ['patron', 'artist'], default: 'patron' },
  liked: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Artwork' }], // new field for liked artworks
  reviewed: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Artwork' }], // new field for artworks reviewed
  workshops: [{ title: String }], // new field for workshops
  enrolledws: [{ title: String }], // new field for enrollied workshops
  following: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // new field for followed artists
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // new field for followers
  notifications: [{
    type: { type: String, enum: ['artwork', 'workshop'] },
    artist: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  }], // new field for storing notifications
});

const User = mongoose.model('User', userSchema);

module.exports = User;